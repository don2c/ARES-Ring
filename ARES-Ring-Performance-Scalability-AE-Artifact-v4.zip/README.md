# ARES-Ring OGTS Fixed-Format Compliance (Artifact)

This artifact computes **proxy** OGTS compliance metrics on the provided Twitter, Facebook, and e-health datasets:

- Transcript byte-length stability: mean/std/max of |Sigma_t| by ring size
- Envelope violation rates: EVR_B and EVR_Δ under envelopes derived from ARES-Ring
- Verifier runtime envelope: mean and tail latencies (p99)
- Branch stability: max observed verification path count (proxy for verifier-side branching)

The baseline systems are **measurement proxies** inspired by the uploaded papers. The script compares their *variable-format* behavior against the fixed-format ARES-Ring envelope.

## Contents
- `src/run_ogts_compliance.py` : main script
- `tables/` : LaTeX tables
- `results/` : CSV summaries (and envelopes)

## Requirements
- Python 3.9+
- `pip install -r requirements.txt`

## Run
1. Put the provided CSVs in `data/`
2. Run:
   ```bash
   python3 src/run_ogts_compliance.py
   ```
3. Tables are written to `tables/*.tex`

## Notes
- This is a functional AE-style artifact for **metric generation** and **reporting**.
- It does not implement the cryptographic primitives; sizes and timings are calibrated as fixed/variable envelopes to support OGTS-style evaluation claims.
