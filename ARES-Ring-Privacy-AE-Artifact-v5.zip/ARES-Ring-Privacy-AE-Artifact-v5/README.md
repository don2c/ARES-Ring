# ARES-Ring Privacy & Indistinguishability Artifact (v5)

This artifact reproduces Evaluation (3): Privacy and indistinguishability metrics, using the uploaded OSN and eHealth datasets.

## What this artifact produces
- `tables_privacy.tex`: LaTeX tables with in-text citations for baselines (as used in the paper).
- `privacy_metrics_summary.csv`: machine-readable copy of the same results.
- `run_privacy_eval.py`: script that writes the tables/CSV into `./out/`.

## Datasets (expected in `./data/`)
- `prime_ring_osn_twitter_users.csv`
- `prime_ring_osn_twitter_edges.csv`
- `prime_ring_osn_twitter_actions.csv`
- `prime_ring_osn_facebook_users.csv`
- `prime_ring_osn_facebook_edges.csv`
- `prime_ring_osn_facebook_actions.csv`
- `prime_ring_ehealth_access_log.csv`
- `prime_ring_ehealth_staff_graph_edges.csv`

## Run
```bash
python3 run_privacy_eval.py --data_dir ./data --out_dir ./out
```

## Notes on baselines and citations (table row labels)
- IoMT-SeqMS corresponds to the uploaded paper “Anonymity-Enhanced Sequential Multi-Signer Ring Signature for Secure Medical Data Sharing in IoMT” (cite key: `11017768`).
- RAT-Ring corresponds to the uploaded paper “RAT-Ring Event-Driven Publish-Subscribe Communication Protocol for IIoT by Report and Traceable Ring Signature” (cite key: `11023615`).
- DecSig-AC / PDecSig-AC corresponds to the uploaded paper “Privacy-Preserving Decentralized Signature-Based Access Control” (cite key: `10979484`).
- RingCT corresponds to the uploaded paper “Concise RingCT Protocol Based on Linkable Threshold Ring Signature” (cite key: `10440486`).

The citation keys above are used exactly in `tables_privacy.tex` as requested.
