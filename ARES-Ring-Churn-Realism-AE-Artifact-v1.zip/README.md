# ARES-Ring AE Artifact: Dataset-grounded churn realism (Metric Set 5)

This package computes three metrics from uploaded datasets:
1) churn intensity distribution,
2) constraint-change mix,
3) burstiness (inter-update interval tails).

## Input datasets
- prime_ring_osn_twitter_actions.csv
- prime_ring_osn_facebook_actions.csv
- prime_ring_ehealth_access_log.csv

## Output
- `results_tables.tex` (LaTeX tables)
- `churn_intensity_metrics.csv`
- `constraint_change_mix.csv`
- `burstiness_metrics.csv`

## Notes
- OSN windows are epoch-based.
- E-health windows are day-based.
- Update-type mapping is trace-derived:
  - OSN action types -> {narrow, pause, revoke, time_change, location_change, purpose_change}
  - E-health uses consent/status/context transitions and override flags to infer update type.
